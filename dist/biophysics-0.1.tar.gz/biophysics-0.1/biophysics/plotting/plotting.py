#!/usr/bin/env python3

def make_pdf(pdf_name):

    import matplotlib.backends.backend_pdf
    pdf = matplotlib.backends.backend_pdf.PdfPages(pdf_name)

    return pdf